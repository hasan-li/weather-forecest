export const baseApiUrl = 'https://api.openweathermap.org/data/2.5/forecast';
export const baseUrl = 'https://openweathermap.org';
export const apiKey = '85a1f57c804b9e6cbcf5598c20039503';